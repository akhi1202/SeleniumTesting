package QAmonCodeTestByAkhi;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import QAmonCodeTestByAkhi.SignInPage_Object_Locator;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class SignInPage_POM_TestNG {
	

/*
		// TODO Auto-generated method stub
		
		WebDriver driver=null;
		
		@BeforeTest
		
		public void setUpTest() {
			// TODO Auto-generated method stub
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			
		}
		
@Test
	   public void testStep1() throws InterruptedException {
		// TODO Auto-generated method stub
		driver.get("https://www.acquireangel.com/signin");
		Thread.sleep(2000);
		
		// mail
		SignInPage_Object_Locator.email(driver).sendKeys("hamidsaymon9@gmail.com");
		
		// password 
		SignInPage_Object_Locator.password(driver).sendKeys("Abc12345");
		
		// remember me 
		SignInPage_Object_Locator.rememberme(driver).click();
		
		// sign in button 
		SignInPage_Object_Locator.signinbutton(driver).click();
		
	}
	
	@AfterTest
	public void tearDown()
{
	driver.close();
	//driver.quit();
	
	
}}*/

//Use the @BeforeTest, @Test, @AfterTest annotation
		// create class variable
		WebDriver driver=null;
		
		// Before test function
		
			@BeforeTest
			public void setUpTest()
			{
				WebDriverManager.chromedriver().setup();
				driver=new ChromeDriver();
			}
		
			//Test function
			
			@Test
			public void testStep1() throws InterruptedException
			{
				driver.get("https://www.acquireangel.com/signin");
				
				// username test action
				SignInPage_Object_Locator.email(driver).sendKeys("hamidsaymon9@gmail.com");
				
				// password test action
				SignInPage_Object_Locator.password(driver).sendKeys("Abc12345");
				
				// remember me test action
				SignInPage_Object_Locator.rememberme(driver).click();
				
				// sign in button test action
				SignInPage_Object_Locator.signinbutton(driver).click();
				
				Thread.sleep(3000);
			}
			
			
		// close function
			@AfterTest
			public void tearDown()
		{
			driver.close();
		}
}

	


